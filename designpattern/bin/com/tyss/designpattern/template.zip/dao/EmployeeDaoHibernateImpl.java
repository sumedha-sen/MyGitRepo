package com.tyss.designpattern.dao;

import com.tyss.designpattern.dto.PrimaryInfo;

public class EmployeeDaoHibernateImpl implements EmployeeDAO {

	@Override
	public PrimaryInfo getSingleRecord() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void getAllRecords() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertRecord(PrimaryInfo info) {
		// TODO Auto-generated method stub
		
	}



}
