package com.tyss.designpattern.dao;

import com.tyss.designpattern.dto.PrimaryInfo;

public interface EmployeeDAO {
	
	public PrimaryInfo getSingleRecord();
	
	public void getAllRecords();
	
	public void insertRecord(PrimaryInfo info);

}
