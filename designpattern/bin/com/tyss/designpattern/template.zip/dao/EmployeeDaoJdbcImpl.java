package com.tyss.designpattern.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import com.tyss.designpattern.dto.PrimaryInfo;

public class EmployeeDaoJdbcImpl implements EmployeeDAO {

	@Override
	public PrimaryInfo getSingleRecord() {
		 
		Connection connection=null;
		Statement stmt=null;
		ResultSet resultset=null;
		
		PrimaryInfo info= new PrimaryInfo();
		
		try {
			FileInputStream fileinputstream=new FileInputStream("dbinfo.properties");
			Properties properties=new Properties();
			properties.load(fileinputstream);
			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection=DriverManager.getConnection(properties.getProperty("dburl"),properties);
			String query="select * from primary_info where id=21";
			
			stmt=connection.createStatement();
		
			resultset=stmt.executeQuery(query);
			
			while(resultset.next()) {
				
				info.setId(resultset.getInt("id"));
				info.setName(resultset.getString("name"));
				info.setDob(resultset.getDate("dob"));
				info.setPhoneNumber(resultset.getLong("phoneno"));
				
			 	
			}
			return info;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			try {
				if(connection!=null) {
					connection.close();
				}
				if(stmt!=null) {
					stmt.close();
				}
				
				
			}catch(Exception e) {
				e.printStackTrace();
				
			}
			
			return info;
		}
		
	}

	@Override
	public void getAllRecords() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertRecord(PrimaryInfo info) {
		// TODO Auto-generated method stub
		
	}




	

}
