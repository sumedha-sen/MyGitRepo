package com.tyss.designpattern.service;

import com.tyss.designpattern.dto.PrimaryInfo;

public interface Service {
	
public PrimaryInfo getSingleRecord();
	
	public void getAllRecords();
	
	public void insertRecord(PrimaryInfo info);


}
