package com.tyss.designpattern.service;

import com.tyss.designpattern.dao.EmployeeDAO;
import com.tyss.designpattern.dto.PrimaryInfo;
import com.tyss.designpattern.factory.GetDaoImpl;

public class EmployeeServiceJdbcImpl implements Service {
	
	GetDaoImpl daoimpl=new GetDaoImpl();
	EmployeeDAO dao=daoimpl.getDAOImpl();
	
	
	@Override
	public PrimaryInfo getSingleRecord() {
		// TODO Auto-generated method stub
		return dao.getSingleRecord(); 
	}
	
	@Override
	public void getAllRecords() {
		// TODO Auto-generated method stub
		dao.getAllRecords();
		
	}
	@Override
	public void insertRecord(PrimaryInfo info) {
		// TODO Auto-generated method stub
		dao.insertRecord(info);
		
	}

	

	


   }


