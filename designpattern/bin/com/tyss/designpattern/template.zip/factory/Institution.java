package com.tyss.designpattern.factory;

public class Institution extends Plan {

	@Override
	public void setRate() {
		super.rate=7;
		
	}

}
