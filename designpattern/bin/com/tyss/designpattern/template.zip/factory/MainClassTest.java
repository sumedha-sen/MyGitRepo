package com.tyss.designpattern.factory;

import com.tyss.designpattern.dto.PrimaryInfo;
import com.tyss.designpattern.service.EmployeeServiceJdbcImpl;
import com.tyss.designpattern.service.Service;

public class MainClassTest {
	
	public static void main(String[] args) {
		
		 Service dao= new EmployeeServiceJdbcImpl();
		 
		 PrimaryInfo info=dao.getSingleRecord();
		 
		 System.out.println(info.getName());
		 System.out.println(info.getPhoneNumber());
		 
		
	}

}
