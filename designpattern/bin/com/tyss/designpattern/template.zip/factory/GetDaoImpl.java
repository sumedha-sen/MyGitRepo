package com.tyss.designpattern.factory;

import com.tyss.designpattern.dao.EmployeeDAO;
import com.tyss.designpattern.dao.EmployeeDaoHibernateImpl;
import com.tyss.designpattern.dao.EmployeeDaoJdbcImpl;
import com.tyss.designpattern.dao.EmployeeDaoSpringJdbcImpl;

public class GetDaoImpl {
	
	String type="jdbc";
	public EmployeeDAO getDAOImpl(){
		
		if(type.equalsIgnoreCase("jdbc")) {
			return new EmployeeDaoJdbcImpl();
		}else if(type.equalsIgnoreCase("hibernate")) {
			
			return new EmployeeDaoHibernateImpl();
			
		}else if(type.equalsIgnoreCase("springjdbc")) {
			return new EmployeeDaoSpringJdbcImpl();
			
			
		}
		return null;
			
			
		
	}

}
