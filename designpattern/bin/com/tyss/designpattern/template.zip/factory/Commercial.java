package com.tyss.designpattern.factory;

public class Commercial extends Plan{

	@Override
	public void setRate() {
	     rate=20;
		
	}

}
