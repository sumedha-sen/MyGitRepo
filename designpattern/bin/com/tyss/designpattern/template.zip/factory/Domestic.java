package com.tyss.designpattern.factory;

public class Domestic extends Plan{

	@Override
	public void setRate() {
		// TODO Auto-generated method stub
		rate=10;
		
	}

}
