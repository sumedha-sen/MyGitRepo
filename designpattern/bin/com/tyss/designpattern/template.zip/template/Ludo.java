package com.tyss.designpattern.template;

public class Ludo extends Game {

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("loading started");
		
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("ludo game started");
		
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		System.out.println("ludo game ended");
		
	}

}
